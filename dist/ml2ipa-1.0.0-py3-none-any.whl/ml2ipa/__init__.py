from .ml2ipa import get_ipa
__all__ = [get_ipa]
